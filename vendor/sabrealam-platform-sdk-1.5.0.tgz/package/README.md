# @definitely/platform-sdk

The unified Frontend Design System and Client SDK for all **Definitely** platforms (`Parent_Portal`, `Meet`, `Prep`, and `Accounts`).

[![GitHub Packages](https://img.shields.io/badge/registry-GitHub%20Packages-blue.svg)](https://npm.pkg.github.com)
[![TypeScript](https://img.shields.io/badge/TypeScript-Strict-blue.svg)](https://www.typescriptlang.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## Features

- 🎨 **Modern Design System**: Accessible, production-ready React components (Button, Input, Card, Modal, Tabs, Toast, Badge, Avatar, Spinner, PlatformHeader, PlatformFooter).
- 🌓 **Light & Dark Theme Engine**: Built-in `ThemeProvider` with CSS variable tokens and zero-config dark mode.
- 🔐 **Unified Cross-Subdomain Auth**: `AuthProvider`, `useUser()`, and `<RequireAuth />` engineered for `.definitely.live` parent-domain cookie authentication.
- 🌐 **Robust API Client**: Typed `ApiClient` with request/response interceptors, automatic error handling, and bearer token support.
- 📡 **Cross-Tab Event Bus**: Real-time cross-tab synchronization using `BroadcastChannel` (e.g., instant multi-tab logout).
- 📦 **Dual ESM & CommonJS**: Bundled via `tsup` with high-performance tree-shaking and complete `.d.ts` type declarations.

---

## Installation

### 1. Authenticate with GitHub Packages

Create or edit your `~/.npmrc` or `.npmrc` in your project root:

```ini
@definitely:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=YOUR_GITHUB_PERSONAL_ACCESS_TOKEN
```

*(Replace `@definitely` with `@sabrealam` if your repository is published under a personal GitHub handle)*.

### 2. Install Package

```bash
npm install @definitely/platform-sdk
```

---

## Quick Start

### 1. Import CSS Styles

Import the platform stylesheet once in your app's main entry (`main.tsx` or `App.tsx`):

```tsx
import '@definitely/platform-sdk/styles.css';
```

### 2. Wrap with Providers

Wrap your root application with `ThemeProvider` and `AuthProvider`:

```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { ThemeProvider, AuthProvider, ToastProvider } from '@definitely/platform-sdk';
import App from './App';
import '@definitely/platform-sdk/styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ThemeProvider defaultTheme="system">
      <AuthProvider>
        <ToastProvider>
          <App />
        </ToastProvider>
      </AuthProvider>
    </ThemeProvider>
  </React.StrictMode>
);
```

---

## Usage Guide

### UI Components

#### Buttons
```tsx
import { Button } from '@definitely/platform-sdk';

function Actions() {
  return (
    <div style={{ display: 'flex', gap: '0.5rem' }}>
      <Button variant="primary">Primary</Button>
      <Button variant="secondary">Secondary</Button>
      <Button variant="outline">Outline</Button>
      <Button variant="danger">Delete</Button>
      <Button variant="primary" isLoading>Saving...</Button>
    </div>
  );
}
```

#### Inputs & Forms
```tsx
import { Input, PasswordInput, SearchInput } from '@definitely/platform-sdk';

function Form() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '360px' }}>
      <Input label="Email address" placeholder="alex@definitely.live" />
      <PasswordInput label="Password" />
      <SearchInput placeholder="Search platforms..." />
    </div>
  );
}
```

#### Modals
```tsx
import { useState } from 'react';
import { Modal, Button } from '@definitely/platform-sdk';

function ExampleModal() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setOpen(true)}>Open Modal</Button>
      <Modal
        isOpen={open}
        onClose={() => setOpen(false)}
        title="Schedule Interview"
        description="Choose a date and time for the mock session"
        footer={
          <>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => setOpen(false)}>Confirm</Button>
          </>
        }
      >
        <p>Modal content goes here.</p>
      </Modal>
    </>
  );
}
```

#### Global Toast Notifications
```tsx
import { useToast, Button } from '@definitely/platform-sdk';

function FeedbackButton() {
  const toast = useToast();

  return (
    <Button
      onClick={() => toast.success('Interview scheduled successfully!', { title: 'Success' })}
    >
      Show Toast
    </Button>
  );
}
```

---

### Client SDK & Authentication

#### Checking Authentication (`useUser`)
```tsx
import { useUser } from '@definitely/platform-sdk';

function UserGreeting() {
  const { user, loading, logout } = useUser();

  if (loading) return <div>Checking session...</div>;
  if (!user) return <a href="https://accounts.definitely.live/login">Sign in</a>;

  return (
    <div>
      <p>Welcome, {user.name} ({user.role})</p>
      <button onClick={() => logout()}>Log out</button>
    </div>
  );
}
```

#### Route Protection (`<RequireAuth />`)
```tsx
import { RequireAuth } from '@definitely/platform-sdk';

function ProtectedPage() {
  return (
    <RequireAuth requiredRole={['mentor', 'interviewer', 'admin']}>
      <DashboardView />
    </RequireAuth>
  );
}
```

#### Standard API Client
```tsx
import { apiClient } from '@definitely/platform-sdk';

async function fetchCandidates() {
  try {
    const res = await apiClient.get('/api/candidates');
    console.log(res.data);
  } catch (error) {
    console.error('API Error:', error);
  }
}
```

---

## Subpath Imports

For optimal bundle tree-shaking, you can import only the specific layer you need:

```tsx
// UI layer only
import { Button, Card, ThemeProvider } from '@definitely/platform-sdk/ui';

// SDK layer only
import { useUser, apiClient, AuthProvider } from '@definitely/platform-sdk/sdk';
```

---

## Publishing to GitHub Packages

1. Update version in `package.json`:
   ```bash
   npm version patch # or minor / major
   ```
2. Build and verify:
   ```bash
   npm run prep-publish
   ```
3. Push tags to trigger GitHub Actions automated release:
   ```bash
   git push origin --tags
   ```
   Or publish manually via CLI:
   ```bash
   npm publish
   ```

---

## License

MIT © Definitely Platform Team
